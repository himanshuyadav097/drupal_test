<?php
/**
 * @file
 * Integrating BxSlider with Views Slideshow.
 */
?>
<li id="views_slideshow_cycle_div_<?php print $variables['vss_id']; ?>_<?php print $variables['current_row']; ?>" class="<?php print $classes; ?>">
  <?php print $items; ?>
</li>
